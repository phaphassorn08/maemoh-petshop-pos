<table>
    <thead>
        <th>No</th>
        <th>Date</th>
        <th>Total Revenue</th>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>    
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($report['date']); ?></td>
                <td>$<?php echo e($report['revenue']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>No records found</td>
            </tr>
        <?php endif; ?>

        <?php if($reports): ?>
            <tr>
                <td>Total</td>
                <td></td>
                <td><strong>$<?php echo e(number_format($total_revenue,2)); ?></strong></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\laravel-pos-app-master\resources\views/admin/reports/exports/revenue-excel.blade.php ENDPATH**/ ?>