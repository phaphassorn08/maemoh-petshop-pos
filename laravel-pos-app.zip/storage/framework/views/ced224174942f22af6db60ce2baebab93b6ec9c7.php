<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<!-- Content Row -->
        <div class="card shadow">
            <div class="card-header">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h3 class="h3 mb-0 text-gray-800"><?php echo e(__('เพิ่มสถานะ')); ?></h3>
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-primary btn-sm shadow-sm"><?php echo e(__('ย้อนกลับ')); ?></a>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.roles.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title"><?php echo e(__('ระดับผู้ใช้')); ?></label>
                        <input type="text" class="form-control" id="title" placeholder="<?php echo e(__('ระดับผู้ใช้')); ?>" name="title" value="<?php echo e(old('title')); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="permissions"><?php echo e(__('การอนุญาต')); ?></label>
                        <select name="permissions[]" id="permissions" class="form-control select2" multiple="multiple" required>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('permissions', [])) || isset($role) && $role->permissions->contains($id)) ? 'selected' : ''); ?>><?php echo e($permissions); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('บันทึก')); ?></button>
                </form>
            </div>
        </div>
    

    <!-- Content Row -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-pos-app-master\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>