<style type="text/css">
img.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 150px;
  height: 150px;
}
</style>

<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <br>
            <img class="img-profile rounded-circle center" src="<?php echo e(asset('backend/img/profile.jpg')); ?>" >
            <a class="sidebar-brand d-flex align-items-center justify-content-center" >
                <div class="sidebar-brand-text mx-3"><h5><?php echo e(__('แม่เมาะเพ็ทช็อป')); ?></h5></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item <?php echo e(request()->is('admin/dashboard') || request()->is('admin/dashboard') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.dashboard.index')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span><?php echo e(__('Dashboard')); ?></span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <span><?php echo e(__('จัดการผู้ใช้')); ?></span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>"> <i class="fa fa-user mr-2"></i> <?php echo e(__('จัดการผู้ใช้')); ?></a>
                        <a class="collapse-item <?php echo e(request()->is('admin/roles') || request()->is('admin/roles/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.roles.index')); ?>"><i class="fa fa-briefcase mr-2"></i> <?php echo e(__('จัดการสถานะ')); ?></a>
                    </div>
                </div>
            </li>

            <li class="nav-item <?php echo e(request()->is('admin/categories') || request()->is('admin/categories') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.categories.index')); ?>">
                    <i class="fas fa-fw fa-cogs"></i>
                    <span><?php echo e(__('จัดการประเภทสินค้า')); ?></span></a>
            </li>

            <li class="nav-item <?php echo e(request()->is('admin/products') || request()->is('admin/products') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.products.index')); ?>">
                    <i class="fas fa-fw fa-box"></i>
                    <span><?php echo e(__('จัดการรายการสินค้า')); ?></span></a>
            </li>

            <li class="nav-item <?php echo e(request()->is('admin/pos') || request()->is('admin/pos') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.pos.index')); ?>">
                    <i class="fas fa-fw fa-cash-register"></i>
                    <span><?php echo e(__('ออเดอร์')); ?></span></a>
            </li>

            <li class="nav-item <?php echo e(request()->is('admin/transactions') || request()->is('admin/transactions') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.transactions.index')); ?>">
                    <i class="fas fa-fw fa-list"></i>
                    <span><?php echo e(__('จัดการประวัติการขาย')); ?></span></a>
            </li>
            
            <li class="nav-item <?php echo e(request()->is('admin/reports/revenue') || request()->is('admin/reports/revenue') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.reports.revenue')); ?>">
                    <i class="fas fa-fw fa fa-table"></i>
                    <span><?php echo e(__('จัดการรายงาน')); ?></span></a>
            </li>


        </ul><?php /**PATH C:\xampp\htdocs\final_project\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>